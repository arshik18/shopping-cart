const initialState = {
  cartCounter: 0,
  cartItemList: [],
  totalPrice: 0,
};

const newTotalPrice = (cartItemList) => {
  let newTotalPrice = 0;
  for (let i = 0; i < cartItemList.length; i++) {
    newTotalPrice =
      newTotalPrice + cartItemList[i].price * cartItemList[i].quantity;
  }
  return newTotalPrice;
};

const reducer = (state = initialState, action) => {
  if (action.type === "ADD_ITEM_TO_CART") {
    //To check whether the item clicked already exist in cart or not
    let indexOfId = state.cartItemList.findIndex(
      (item) => item.id === action.product.id
    );
    //If item does not exist in the cart add it to the view cart list,increase cart counter and set the total price
    if (indexOfId === -1) {
      state.cartCounter = state.cartCounter + 1;
      state.totalPrice = state.totalPrice + action.product.price;
      state.cartItemList = [...state.cartItemList, action.product];
    }
    //If item already exist increase its quantity and set the new price
    else {
      let newCartItemList = [...state.cartItemList];
      newCartItemList[indexOfId] = {
        ...newCartItemList[indexOfId],
        quantity: newCartItemList[indexOfId].quantity + 1,
      };
      state.cartItemList = [...newCartItemList];
      state.totalPrice = newTotalPrice(state.cartItemList);
    }
    return {
      ...state,
    };
  }
  if (action.type === "DELETE_ITEM_FROM_CART") {
    let indexOfId = state.cartItemList.findIndex((i) => i.id === action.id);
    let updatedCartItemList = [...state.cartItemList];
    updatedCartItemList.splice(indexOfId, 1);
    state.cartItemList = [...updatedCartItemList];
    state.totalPrice = newTotalPrice(state.cartItemList);
    return {
      ...state,
      cartCounter: state.cartCounter-1
    };
  }
  if (action.type === "ON_QUANTITY_CHANGE") {
    let indexOfId = state.cartItemList.findIndex((i) => i.id === action.id);
    let newCartItemList = [...state.cartItemList];
    newCartItemList[indexOfId] = {
      ...newCartItemList[indexOfId],
      quantity: action.quantity,
    };
    state.cartItemList = [...newCartItemList];
    state.totalPrice = newTotalPrice(state.cartItemList);

    return {
      ...state,
    };
  }
  if(action.type === "EMPTY CART"){
    return{
      ...state,
      cartItemList: [],
      cartCounter:0,
      totalPrice:0
    }
  }
  return state;
};

export default reducer;
