 /* export default{
    products: ()=> `https://5f44e6873fb92f001675403e.mockapi.io/api/products`
}  */
export const products ='https://5f44e6873fb92f001675403e.mockapi.io/api/products';
export const orders ='https://5f44e6873fb92f001675403e.mockapi.io/api/orders';