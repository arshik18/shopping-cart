import axios from 'axios';
import * as endpoints from '../services/endpoints';

export const getProductsListService = () => {
    return axios.get(endpoints.products);
  };