import React from "react";
import "./index.module.css";
import {Row,Col,Card} from "react-bootstrap";
import classes from "./index.module.css";
const Orders = (props) => {
    const {name,avatar,description,price} = props;
  return (
    <Row className={classes.orderRow}>
                    <Col className={classes.imageCol} xs="3">
                      <Card className={classes.ordersCard}>
                        <Card.Img src={avatar} />
                      </Card>
                    </Col>
                    <Col xs="4">
                      <p className={classes.labelName}>{name}</p>
                      <p>{description}</p>
                      </Col>
                      <Col xs="2"
                      className={classes.labelName}>
                          <p>₹: {price}</p>
                      </Col>
                      <Col className={classes.labelName}>
                          <p>Delivered On {price}</p>
                      </Col>
                      
                    
                  </Row>
                 
      
      
  );
};

export default Orders;
