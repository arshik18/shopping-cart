import React from "react";
import classes from "./index.module.css";
import {
  Navbar,
  NavDropdown,
  InputGroup,
  Badge,
  Nav,
  FormControl,
  Form,
} from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faSearch,
  faShoppingCart,
  faHeart,
  faUser,
  faSignOutAlt,
  faClipboardList,
} from "@fortawesome/free-solid-svg-icons";
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';

const TopNavbar = (props) => {

  const {counter} = props;
  return (
    <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
      <Link to="/"><Navbar.Brand>E-Cart</Navbar.Brand></Link>
      <Navbar.Toggle aria-controls="responsive-navbar-nav" />
      <Navbar.Collapse id="responsive-navbar-nav">
        <Nav className="mr-auto">
          <Nav.Link href="#features">Features</Nav.Link>
          <Nav.Link href="#pricing">Pricing</Nav.Link> 
          <Form inline>
            <InputGroup>
              <FormControl
                placeholder="Username"
                aria-label="Username"
                aria-describedby="basic-addon1"
              />
              <InputGroup.Prepend>
                <InputGroup.Text id="basic-addon1" className={classes.search}>
                  <FontAwesomeIcon icon={faSearch} />
                </InputGroup.Text>
              </InputGroup.Prepend>
            </InputGroup>
          </Form>
        </Nav>
        <Nav>
          <NavDropdown title="Arshi" id="collasible-nav-dropdown">
            <NavDropdown.Item href="#action/3.1">
              <FontAwesomeIcon icon={faUser} />
              &nbsp; My Profile
            </NavDropdown.Item>
            <NavDropdown.Divider />
            <NavDropdown.Item href="#action/3.2">
              <FontAwesomeIcon icon={faClipboardList} />
              &nbsp; Orders
            </NavDropdown.Item>
            <NavDropdown.Divider />
            <NavDropdown.Item href="#action/3.3">
              <FontAwesomeIcon icon={faHeart} />
              &nbsp; Wish List
            </NavDropdown.Item>
            <NavDropdown.Divider />
            <NavDropdown.Item href="#action/3.4">
              <FontAwesomeIcon icon={faSignOutAlt} />
              &nbsp; Logout
            </NavDropdown.Item>
          </NavDropdown>
        </Nav>
        <Nav>
          <Nav.Link href="#deets">
            <FontAwesomeIcon icon={faHeart} />
          </Nav.Link>
          <Nav.Link eventKey={2} >
            <Link to="/view-cart" ><FontAwesomeIcon icon={faShoppingCart} />
            <Badge pill variant="light" className={classes.badge}>
              {counter}
            </Badge></Link>
          </Nav.Link>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
};

const mapStateToProps = state =>{
  return{
    counter: state.cartCounter
  }
}

export default connect(mapStateToProps)(TopNavbar);
