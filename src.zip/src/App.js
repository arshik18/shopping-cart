import React from 'react';
import Home from './containers/Home';
import './App.css';
import {Route} from 'react-router-dom';
import TopNavbar from './components/TopNavbar';
import ViewCartContainer from './containers/ViewCart';
import OrdersContainer from './containers/Orders';

function App() {
  return (
    <React.Fragment>
    <TopNavbar/>
    <Route path="/" exact component ={Home}/>
    <Route path="/view-cart" exact component ={ViewCartContainer}/>
    <Route path="/orders" exact component ={OrdersContainer}/>
    </React.Fragment>
  );
}

export default App;
