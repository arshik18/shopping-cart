import React from 'react';
import './index.module.css';
import ViewCart from '../../components/ViewCart';
import {connect} from 'react-redux';
import {postOrdersService} from "../../services/orders.service";

const ViewCartContainer = (props) =>{

    const{cartItemList,cartCounter,emptyCart} = props;
    
    
    const placeOrder =()=>{
        console.log(cartItemList,"cartItemList");
        postOrdersService({products:cartItemList}).then(response=>
            {
                emptyCart();
            }   
        )
        } 

      
    return(
        <div>
            <ViewCart 
                cartCounter={cartCounter} 
                cartItemList={cartItemList}
                placeOrder={placeOrder} />
        </div>
    )
}
const mapStateToProps = state => {
    return{
        cartItemList: state.cartItemList,
        cartCounter: state.cartCounter
    }
}
const mapDispatchToProps = dispatch =>{
    return{
        emptyCart : () => dispatch({type:"ËMPTY_CART"})
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(ViewCartContainer);
