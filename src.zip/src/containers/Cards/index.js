import React, { useState, useEffect } from "react";
import classes from "./index.module.css";
import Cards from "../../components/common/Cards";
import CardColumns from "react-bootstrap/CardColumns";
import { getProductsListService } from "../../services/products.service.js";
import {connect} from 'react-redux';
const CardsContainer = (props) => {

  const [productsList, setProductsList] = useState([]);

  useEffect(() => {
    //Api call for Product List
    getProductsListService().then((response) => {
      setProductsList(response.data);
      console.log(productsList,"productList");
    });
  }, []);

 
  console.log(productsList,"productList");
  return (
    <CardColumns className={classes.cardColumn}>
      {productsList &&
        productsList.map((product) => {
          return (
            <Cards
              key={product.id}
              image={product.avatar}
              name={product.name}
              price={product.price}
              description={product.description}
              addToCart={()=>{
                Object.assign(product,{quantity:1})
                props.addItems(product)}}
            />
          );
        })}
    </CardColumns>
  );
};
const mapStateToProps = state =>{
    return{
        counter: state.cartCounter,
        cartcartItemList: state.cartItemList
    }
}
const mapDispatchToProps = dispatch =>{
    return{
        /* onAddToCart: ()=> dispatch({type: 'INCREMENT_CART_COUNTER'}), */
        addItems: (product) => dispatch({type: 'ADD_ITEM_TO_CART', product: product})
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(CardsContainer);
