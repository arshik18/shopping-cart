import React, { useState, useEffect } from "react";
import "./index.module.css";
import ViewOrders from "../../components/Orders";
import {getOrdersService } from "../../services/orders.service";
import { connect } from "react-redux";
import {Container} from 'react-bootstrap';
import classes from './index.module.css';

const OrdersContainer = (props) => {
  const [getOrders, setGetOrders] = useState([]);
  useEffect(() => {
      getOrdersService().then(response =>{
        setGetOrders(response.data);
        console.log(response.data,"ordersresp");
        console.log(getOrders,"getOrders");
      })},[]);

  return(
      <Container className={classes.ordersContainer}>
       {getOrders ? <div>Hello</div> : <div>hi</div>}
       {getOrders && getOrders.map( orders =>{
            orders.products.map(product =>{
              return(
                <ViewOrders
                key={product.id}
                name={product.name}
                avatar={product.avatar}
                description={product.description}
                price={product.price}
                />
            )
            })
            
       })}
      </Container>
     
  )

}
const mapStateToProps = (state) => {
  return {
    cartItemList: state.cartItemList,
  };
};
export default connect(mapStateToProps)(OrdersContainer);
